import pandas as pd
from trainer import Trainer
from tts import TTSConfig

# Load the configuration file
config = TTSConfig.load('config_english.json')

# Load the dataset
dataset = pd.read_csv('english_dataset.csv')

# Prepare the trainer
trainer = Trainer(config)

# Start training
trainer.fit(dataset)

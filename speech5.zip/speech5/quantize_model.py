import torch
from tts import TTS

# Load the model
model = TTS.load("E:/speech5/final_model.pth")  

# Set the model to evaluation mode
model.eval()

# Perform post-training quantization
model.qconfig = torch.quantization.default_qconfig
torch.quantization.prepare(model, inplace=True)
torch.quantization.convert(model, inplace=True)

# Save the quantized model
torch.save(model.state_dict(), "output_model_english/quantized_model.pth")
print("Quantized model saved.")

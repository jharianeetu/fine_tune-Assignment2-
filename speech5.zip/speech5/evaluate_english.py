from tts import TTS
import json

# Load the model
model = TTS.load("e:/speech5/final_model.pth")  

# Load evaluation sentences from the config file
with open('config_english.json', 'r') as f:
    config = json.load(f)

test_sentences = config['evaluation']['test_sentences']

# Evaluate the model on technical terms
for sentence in test_sentences:
    audio_output = model.speak(sentence)
    print(f"Generated audio for: '{sentence}'")

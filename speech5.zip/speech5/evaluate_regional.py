from tts import TTS
import json

# Load the model
model = TTS.load("E:/speech5/final_model.pth")  

# Load evaluation sentences from the config file
with open('config_regional.json', 'r') as f:
    config = json.load(f)

test_sentences = config['evaluation']['test_sentences']

# Evaluate the model on regional sentences
for sentence in test_sentences:
    audio_output = model.speak(sentence)
    print(f"Generated audio for: '{sentence}'")

import pandas as pd
from trainer import Trainer
from tts import TTSConfig

# Load the configuration file
config = TTSConfig.load('config_regional.json')

# Load the dataset
dataset = pd.read_csv('regional_language_dataset.csv')

# Prepare the trainer
trainer = Trainer(config)

# Start training
trainer.fit(dataset)
